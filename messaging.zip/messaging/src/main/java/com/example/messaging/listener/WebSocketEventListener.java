package com.example.messaging.listener;

import com.example.messaging.service.MessagingService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.event.EventListener;
import org.springframework.messaging.simp.stomp.StompHeaderAccessor;
import org.springframework.stereotype.Component;
import org.springframework.web.socket.messaging.SessionConnectedEvent;

@Component
public class WebSocketEventListener {

    private final MessagingService messagingService;

    @Autowired
    public WebSocketEventListener(MessagingService messagingService) {
        this.messagingService = messagingService;
    }

    @EventListener
    public void handleWebSocketConnect(SessionConnectedEvent event) {
        StompHeaderAccessor accessor = StompHeaderAccessor.wrap(event.getMessage());

        if (accessor.getUser() != null) {
            String username = accessor.getUser().getName();
            messagingService.deliverPendingMessages(username); // ✅ Corrected method name
            //System.out.println("📬 Delivered queued messages for: " + username);
        } else {
            //System.out.println("⚠️ WebSocket connected but user is null.");
        }
    }
}
