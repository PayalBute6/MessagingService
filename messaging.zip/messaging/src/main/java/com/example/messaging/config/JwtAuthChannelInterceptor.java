package com.example.messaging.config;

import com.example.messaging.auth.JwtUtil;
import com.example.messaging.service.MessageDeliveryService;
import com.example.messaging.storage.UserStorage;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.server.ServletServerHttpRequest;
import org.springframework.messaging.Message;
import org.springframework.messaging.MessageChannel;
import org.springframework.messaging.simp.stomp.StompCommand;
import org.springframework.messaging.simp.stomp.StompHeaderAccessor;
import org.springframework.messaging.support.ChannelInterceptor;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.stereotype.Component;

import java.security.Principal;
import java.util.Collections;

@Component
public class JwtAuthChannelInterceptor implements ChannelInterceptor {

    @Autowired
    private JwtUtil jwtUtil;

    @Autowired
    private UserStorage userStorage;

    @Autowired
    private MessageDeliveryService messageDeliveryService;

    @Override
    public Message<?> preSend(Message<?> message, MessageChannel channel) {
        StompHeaderAccessor accessor = StompHeaderAccessor.wrap(message);

        if (StompCommand.CONNECT.equals(accessor.getCommand())) {
            String token = null;

            // ✅ 1. Try native WebSocket header
            String authHeader = accessor.getFirstNativeHeader("Authorization");
            System.out.println("📩 Header Authorization: " + authHeader);

            if (authHeader != null && authHeader.startsWith("Bearer ")) {
                token = authHeader.substring(7);
            }

            // ✅ 2. Fallback for SockJS
            if (token == null) {
                Object raw = accessor.getHeader("simpConnectMessage");
                if (raw instanceof Message<?> connectMsg) {
                    ServletServerHttpRequest servletRequest =
                            (ServletServerHttpRequest) connectMsg.getHeaders().get("simpHttpRequest");

                    if (servletRequest != null) {
                        HttpServletRequest request = servletRequest.getServletRequest();
                        token = request.getParameter("token");
                        System.out.println("🧩 Token from query param: " + token);
                    }
                }
            }

            // ✅ 3. Final token check
            if (token == null) {
                System.out.println("❌ No token found in header or query param.");
                return null;
            }

            System.out.println("🔍 Validating token: " + token);

            if (jwtUtil.validateToken(token)) {
                String username = jwtUtil.extractUsername(token);
                System.out.println("✅ Token valid. Authenticated user: " + username);

                Principal principal = new UsernamePasswordAuthenticationToken(
                        username, null, Collections.emptyList());
                accessor.setUser(principal);  // ✅ This is what makes Spring inject it later

                userStorage.setOnline(username, true);
                System.out.println("🧩 Principal set: " + principal);

                // ✅ Deliver any undelivered messages
                messageDeliveryService.deliverQueuedMessages(username);
            } else {
                System.out.println("❌ Invalid JWT token. Connection rejected.");
                return null;
            }
        }

        return message;
    }
}
