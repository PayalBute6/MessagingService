package com.example.messaging.service;

import com.example.messaging.model.Message;
import com.example.messaging.storage.MessageStorage;
import com.example.messaging.storage.UserStorage;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class MessagingService {

    private final SimpMessagingTemplate messagingTemplate;
    private final UserStorage userStorage;
    private final MessageStorage messageStorage;

    @Autowired
    public MessagingService(SimpMessagingTemplate messagingTemplate,
                            UserStorage userStorage,
                            MessageStorage messageStorage) {
        this.messagingTemplate = messagingTemplate;
        this.userStorage = userStorage;
        this.messageStorage = messageStorage;
    }

    /**
     * Process the message: send immediately if receiver is online,
     * otherwise queue it in memory.
     */
    public void processMessage(Message message) {
        System.out.println("💬 Processing message from " + message.getSender()
                + " to " + message.getReceiver() + ": " + message.getText());

        if (userStorage.isOnline(message.getReceiver())) {
            messagingTemplate.convertAndSendToUser(
                    message.getReceiver(),
                    "/queue/messages",
                    message
            );
            System.out.println("📨 Sent message to online user: " + message.getReceiver());
        } else {
            messageStorage.queueMessage(message.getReceiver(), message);
            System.out.println("📥 Queued message for offline user: " + message.getReceiver());
        }
    }

    /**
     * When a user connects via WebSocket, deliver any queued messages.
     */

    public void deliverQueuedMessages(String username) {
        List<Message> undelivered = messageStorage.getMessages(username);
        for (Message msg : undelivered) {
            messagingTemplate.convertAndSendToUser(username, "/queue/messages", msg);
        }
        messageStorage.clearMessages(username);
        System.out.println("✅ Delivered " + undelivered.size() + " queued messages to: " + username);
    }

    public void deliverPendingMessages(String username) {
        List<Message> messages = messageStorage.getAndClearMessages(username);

        if (messages.isEmpty()) {
            System.out.println("📭 No queued messages for: " + username);
        }

        for (Message message : messages) {
            messagingTemplate.convertAndSendToUser(
                    username,
                    "/queue/messages",
                    message
            );
            System.out.println("📤 Delivered queued message to " + username + ": " + message.getText());
        }
    }
}
