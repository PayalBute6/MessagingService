package com.example.messaging.storage;

import com.example.messaging.model.Message;
import org.springframework.stereotype.Component;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

@Component
public class MessageStorage {

    // In-memory store: receiver → list of messages
    private final Map<String, List<Message>> messageMap = new ConcurrentHashMap<>();

    /**
     * ✅ Store a message for a receiver (used for both live and queued)
     */
    public void storeMessage(String receiver, Message message) {
        messageMap
                .computeIfAbsent(receiver, k -> Collections.synchronizedList(new ArrayList<>()))
                .add(message);
    }

    /**
     * ✅ Alias for storeMessage() to emphasize queuing
     */
    public void queueMessage(String receiver, Message message) {
        storeMessage(receiver, message);
    }

    /**
     * ✅ Get all messages for a receiver (non-destructive)
     */
    public List<Message> getMessages(String receiver) {
        return new ArrayList<>(messageMap.getOrDefault(receiver, Collections.emptyList()));
    }

    /**
     * ✅ Clear all stored messages for a receiver
     */
    public void clearMessages(String receiver) {
        messageMap.remove(receiver);
    }

    /**
     * ✅ Retrieve and clear messages in one atomic operation
     */
    public List<Message> getAndClearMessages(String receiver) {
        List<Message> messages = getMessages(receiver);
        clearMessages(receiver);
        return messages;
    }

    /**
     * ✅ Get number of queued messages for a receiver
     */
    public int getMessageCount(String receiver) {
        return messageMap.getOrDefault(receiver, Collections.emptyList()).size();
    }
}
