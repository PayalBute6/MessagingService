package com.example.messaging.storage;

import com.example.messaging.model.User;
import org.springframework.stereotype.Component;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

@Component
public class UserStorage {

    private final Map<String, User> users = new ConcurrentHashMap<>();

    public boolean exists(String username) {
        return users.containsKey(username);
    }

    public void addUser(User user) {
        users.put(user.getUsername(), user);
    }

    public void verifyUser(String username) {
        User user = users.get(username);
        if (user != null) {
            user.setVerified(true);
        }
    }

    public User getUser(String username) {
        return users.get(username);
    }

    public void setOnline(String username, boolean status) {
        User user = users.get(username);
        if (user != null) {
            user.setOnline(status);
        }
    }

    public boolean isOnline(String username) {
        User user = users.get(username);
        return user != null && user.isOnline();
    }
}
