package com.example.messaging.service;

import com.example.messaging.model.Message;
import com.example.messaging.storage.MessageStorage;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class MessageDeliveryService {

    private final SimpMessagingTemplate messagingTemplate;
    private final MessageStorage messageStorage;

    public MessageDeliveryService(SimpMessagingTemplate messagingTemplate,
                                  MessageStorage messageStorage) {
        this.messagingTemplate = messagingTemplate;
        this.messageStorage = messageStorage;
    }

    /**
     * ✅ Called when a user connects.
     * Delivers all stored messages and clears them.
     */
    public void deliverQueuedMessages(String username) {
        List<Message> queuedMessages = messageStorage.getAndClearMessages(username);
        if (queuedMessages.isEmpty()) {
            System.out.println("ℹ️ No queued messages for: " + username);
            return;
        }

        for (Message msg : queuedMessages) {
            messagingTemplate.convertAndSendToUser(username, "/queue/messages", msg);
        }

        System.out.println("✅ Delivered " + queuedMessages.size() + " queued messages to: " + username);
    }

    /**
     * ✅ Immediately deliver a message if the user is online,
     * otherwise store it in memory.
     */
    public void deliverOrQueueMessage(String receiver, Message message, boolean isOnline) {
        if (isOnline) {
            messagingTemplate.convertAndSendToUser(receiver, "/queue/messages", message);
            System.out.println("📤 Delivered live message to: " + receiver);
        } else {
            messageStorage.storeMessage(receiver, message);
            System.out.println("📥 Stored message for offline user: " + receiver);
        }
    }

    /**
     * ✅ Explicit method to queue messages without checking online status.
     */
    public void queueMessage(String receiver, Message message) {
        messageStorage.storeMessage(receiver, message);
        System.out.println("📦 Message added to queue for: " + receiver);
    }
}
