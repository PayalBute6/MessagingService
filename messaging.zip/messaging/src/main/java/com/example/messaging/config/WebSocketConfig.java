package com.example.messaging.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.messaging.simp.config.ChannelRegistration;
import org.springframework.messaging.simp.config.MessageBrokerRegistry;
import org.springframework.web.socket.config.annotation.*;

@Configuration
@EnableWebSocketMessageBroker
public class WebSocketConfig implements WebSocketMessageBrokerConfigurer {

    private final JwtAuthChannelInterceptor jwtAuthChannelInterceptor;

    public WebSocketConfig(JwtAuthChannelInterceptor jwtAuthChannelInterceptor) {
        this.jwtAuthChannelInterceptor = jwtAuthChannelInterceptor;
    }

    /**
     * ✅ Register WebSocket endpoint at /ws with SockJS support
     * SockJS is useful for fallback when native WebSocket is not available in the browser.
     */
    @Override
    public void registerStompEndpoints(StompEndpointRegistry registry) {
        registry.addEndpoint("/ws")
                .setAllowedOriginPatterns("*")
                .withSockJS();  // ✅ Important for fallback support                    // ✅ Enable SockJS fallback
    }

    /**
     * ✅ Configure broker for message routing:
     * - /app is for client messages to @MessageMapping
     * - /user/queue is for private messaging
     * - /topic is for public broadcasting (optional)
     */
    @Override
    public void configureMessageBroker(MessageBrokerRegistry registry) {
        registry.setApplicationDestinationPrefixes("/app");          // Client → Server
        registry.setUserDestinationPrefix("/user");                  // Server → Specific User
        registry.enableSimpleBroker("/topic", "/user/queue");        // In-memory message broker
    }

    /**
     * ✅ Add JWT validation for inbound WebSocket messages
     */
    @Override
    public void configureClientInboundChannel(ChannelRegistration registration) {
        registration.interceptors(jwtAuthChannelInterceptor);
    }
}
