package com.example.messaging.controller;

import com.example.messaging.model.Message;
import com.example.messaging.service.MessageDeliveryService;
import com.example.messaging.storage.UserStorage;
import org.springframework.messaging.handler.annotation.MessageMapping;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.stereotype.Controller;

import java.security.Principal;

@Controller
public class MessageController {

    private final SimpMessagingTemplate messagingTemplate;
    private final UserStorage userStorage;
    private final MessageDeliveryService messageDeliveryService;

    public MessageController(SimpMessagingTemplate messagingTemplate,
                             UserStorage userStorage,
                             MessageDeliveryService messageDeliveryService) {
        this.messagingTemplate = messagingTemplate;
        this.userStorage = userStorage;
        this.messageDeliveryService = messageDeliveryService;
    }

    @MessageMapping("/chat")
    public void sendMessage(Message message, Principal principal) {
        if (principal == null) {
            System.out.println("❌ Principal is null. Message not sent.");
            return;
        }

        String sender = principal.getName();   // ✅ The logged-in user
        String receiver = message.getReceiver();  // ✅ The user to whom this message is sent
        message.setSender(sender); // ⛔️ Never trust frontend for sender value


        System.out.println("📨 Message from [" + sender + "] to [" + receiver + "]: " + message.getText());

        if (receiver == null || receiver.isBlank()) {
            System.out.println("❌ Receiver is missing.");
            return;
        }

        if (userStorage.isOnline(receiver)) {
            messagingTemplate.convertAndSendToUser(receiver, "/queue/messages", message);
            System.out.println("✅ Delivered to online user: " + receiver);
        } else {
            messageDeliveryService.queueMessage(receiver, message);
            System.out.println("⏳ Queued for offline user: " + receiver);
        }

        // ✅ Echo back to sender (for sender's UI)
        messagingTemplate.convertAndSendToUser(sender, "/queue/messages", message);
    }
}
