package com.example.messaging.controller;

import com.example.messaging.auth.JwtUtil;
import com.example.messaging.model.AuthRequest;
import com.example.messaging.model.User;
import com.example.messaging.storage.UserStorage;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
public class AuthController {

    @Autowired private UserStorage userStorage;
    @Autowired private JwtUtil jwtUtil;

    @PostMapping("/register")
    public ResponseEntity<?> register(@RequestBody AuthRequest request) {
        if (userStorage.exists(request.getUsername()))
            return ResponseEntity.badRequest().body("Username exists");
        userStorage.addUser(new User(request.getUsername(), request.getPassword(), false, false));
        return ResponseEntity.ok("Registered. Verify OTP.");
    }

    @PostMapping("/verify")
    public ResponseEntity<?> verify(@RequestParam String username, @RequestParam String otp) {
        if (!userStorage.exists(username)) return ResponseEntity.badRequest().body("User not found");
        if (!"123456".equals(otp)) return ResponseEntity.badRequest().body("Invalid OTP");
        userStorage.verifyUser(username);
        return ResponseEntity.ok("Verified");
    }

    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody AuthRequest request) {
        User user = userStorage.getUser(request.getUsername());
        if (user == null || !user.isVerified() || !user.getPassword().equals(request.getPassword()))
            return ResponseEntity.status(403).body("Invalid login");

        String token = jwtUtil.generateToken(user.getUsername());

        System.out.println("Generated Token: " + token); // ✅ Add this line

        return ResponseEntity.ok(Map.of("token", token)); // Sends it back to Postman
    }

}
