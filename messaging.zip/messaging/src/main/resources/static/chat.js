// ✅ Step 1: Get JWT token
const token = localStorage.getItem("jwtToken");
if (!token) {
    alert("❌ Please log in first.");
    throw new Error("Missing JWT token");
}

// ✅ Step 2: Decode JWT token to extract sender username
function getUsernameFromToken(token) {
    try {
        const payload = token.split('.')[1];
        const decoded = atob(payload.replace(/-/g, '+').replace(/_/g, '/'));
        return JSON.parse(decoded).sub;
    } catch {
        console.error("❌ Token parsing failed.");
        return null;
    }
}
const sender = getUsernameFromToken(token);
if (!sender) {
    alert("❌ Invalid JWT token");
    throw new Error("Token parsing error");
}

// ✅ Step 3: Connect via SockJS + STOMP
let stompClient = null;
connectWebSocket();

function connectWebSocket() {
    const socket = new SockJS("http://localhost:8080/ws");
    stompClient = Stomp.over(socket);
    stompClient.debug = null;

    stompClient.connect(
        { Authorization: "Bearer " + token },
        onConnected,
        onError
    );
    console.log("🔐 Token used for WebSocket:", token);
}

// ✅ Step 4: Connected
function onConnected() {
    console.log(`✅ Connected as ${sender}`);
    stompClient.subscribe("/user/queue/messages", onMessageReceived);
    setOnlineStatus(true);

    const receiver = document.querySelector("#receiver").value.trim();
    if (receiver) loadMessages(receiver);
}

// ❌ Handle error
function onError(err) {
    console.error("❌ WebSocket connection error:", err);
    setOnlineStatus(false);
    reconnect();
}

// ✅ Handle incoming messages
function onMessageReceived(payload) {
    try {
        const msg = JSON.parse(payload.body);
        const timestamp = formatTimestamp(msg.timestamp);
        appendMessage(msg.text, false, msg.sender, timestamp);
        saveMessage(msg.sender, { ...msg, isOwn: false });
    } catch (e) {
        console.error("❌ Message parse error:", e);
    }
}

// ✅ Send message
document.querySelector("#messageForm").addEventListener("submit", e => {
    e.preventDefault();
    const receiver = document.querySelector("#receiver").value.trim();
    const text = document.querySelector("#message").value.trim();

    if (receiver && text) {
        const timestamp = new Date().toISOString();
        const message = { sender, receiver, text, timestamp };

        stompClient.send("/app/chat", {}, JSON.stringify(message));
        appendMessage(text, true, sender, formatTimestamp(timestamp));
        saveMessage(receiver, { ...message, isOwn: true });

        document.querySelector("#message").value = "";
    }
});

// ✅ Append message to chat window
function appendMessage(text, isOwn, user, timestamp) {
    const messageArea = document.querySelector("#messageArea");

    const li = document.createElement("li");
    li.style.display = "flex";
    li.style.justifyContent = isOwn ? "flex-end" : "flex-start";
    li.style.gap = "0.5rem";
    li.style.marginBottom = "6px";

    const avatar = document.createElement("div");
    avatar.textContent = user.charAt(0).toUpperCase();
    avatar.style.width = "30px";
    avatar.style.height = "30px";
    avatar.style.borderRadius = "50%";
    avatar.style.backgroundColor = isOwn ? "#2563eb" : "#999";
    avatar.style.color = "#fff";
    avatar.style.display = "flex";
    avatar.style.alignItems = "center";
    avatar.style.justifyContent = "center";
    avatar.style.fontWeight = "bold";

    const bubble = document.createElement("div");
    bubble.textContent = `${text} (${timestamp})`;
    bubble.style.padding = "8px 12px";
    bubble.style.borderRadius = "10px";
    bubble.style.maxWidth = "60%";
    bubble.style.backgroundColor = isOwn ? "#d0ebff" : "#f1f1f1";

    if (isOwn) {
        li.appendChild(bubble);
        li.appendChild(avatar);
    } else {
        li.appendChild(avatar);
        li.appendChild(bubble);
    }

    messageArea.appendChild(li);
    li.scrollIntoView({ behavior: "smooth", block: "end" });
}

// ✅ Format time
function formatTimestamp(iso) {
    const d = new Date(iso);
    return `${d.toLocaleDateString()} ${d.toLocaleTimeString()}`;
}

// ✅ Online/offline badge
function setOnlineStatus(online) {
    const badge = document.querySelector(".connecting");
    if (badge) {
        badge.textContent = online ? "🟢 Online" : "🔴 Offline";
        badge.style.color = online ? "green" : "red";
    }
}

// ✅ Save message history in localStorage
function saveMessage(withUser, message) {
    const key = `chat_${withUser}`;
    const existing = JSON.parse(localStorage.getItem(key)) || [];
    existing.push(message);
    localStorage.setItem(key, JSON.stringify(existing));
}

// ✅ Load message history from localStorage
function loadMessages(withUser) {
    const key = `chat_${withUser}`;
    const saved = JSON.parse(localStorage.getItem(key)) || [];
    const messageArea = document.querySelector("#messageArea");
    messageArea.innerHTML = "";

    saved.forEach(msg =>
        appendMessage(msg.text, msg.isOwn, msg.sender, formatTimestamp(msg.timestamp))
    );
}

// ✅ Reload messages when receiver changes
document.querySelector("#receiver").addEventListener("blur", function () {
    const receiver = this.value.trim();
    if (receiver) loadMessages(receiver);
});

// ✅ Graceful disconnect on window close
window.addEventListener("beforeunload", () => {
    disconnect();
});

function disconnect() {
    if (stompClient !== null) {
        stompClient.disconnect(() => {
            console.log("🔌 Disconnected");
            setOnlineStatus(false);
        });
    }
}

// ✅ Reconnect on failure
function reconnect() {
    console.log("🔁 Trying to reconnect...");
    setTimeout(() => {
        connectWebSocket();
    }, 5000);
}
