package com.example.messaging;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MessagingApplicationTests {

	@Test
	void contextLoads() {
	}

}
