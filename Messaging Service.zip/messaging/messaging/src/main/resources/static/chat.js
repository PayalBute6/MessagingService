// ✅ Step 1: Get JWT token from local storage
const token = localStorage.getItem("jwtToken");
if (!token) {
    alert("❌ Please log in first.");
    throw new Error("Missing JWT token");
}

// ✅ Step 2: Decode JWT to extract username
function getUsernameFromToken(token) {
    try {
        const payload = token.split('.')[1];
        const decoded = atob(payload.replace(/-/g, '+').replace(/_/g, '/'));
        return JSON.parse(decoded).sub;
    } catch (err) {
        console.error("❌ Token parsing failed.", err);
        return null;
    }
}

const loggedInUser = getUsernameFromToken(token);
if (!loggedInUser) {
    alert("❌ Invalid JWT token");
    throw new Error("Token parsing error");
}

// ✅ Step 3: Connect to WebSocket using SockJS + STOMP
let stompClient = null;

function connectWebSocket() {
    const socket = new SockJS("http://localhost:8080/ws");
    stompClient = Stomp.over(socket);
    stompClient.debug = null; // disable STOMP debug logging

    stompClient.connect(
        { Authorization: "Bearer " + token },
        onConnected,
        onError
    );

    console.log("🔐 Connecting WebSocket with token:", token);
}

connectWebSocket();

// ✅ Step 4: Once connected
function onConnected() {
    console.log(`✅ Connected as ${loggedInUser}`);

    stompClient.subscribe("/user/queue/messages", onMessageReceived);

    setOnlineStatus(true);

    const receiver = document.querySelector("#receiver").value.trim();
    if (receiver) {
        loadMessages(receiver);
    }
}

// ❌ Handle connection error
function onError(error) {
    console.error("❌ WebSocket connection error:", error);
    setOnlineStatus(false);
    reconnect();
}

// ✅ Handle incoming message
function onMessageReceived(payload) {
    if (!payload || !payload.body) {
        console.warn("⚠️ Empty message payload received");
        return;
    }

    try {
        const msg = JSON.parse(payload.body);
        const timestamp = formatTimestamp(msg.timestamp);

        // Update UI
        appendMessage(msg.text, msg.sender === loggedInUser, msg.sender, timestamp);

        // Save in localStorage
        const chatKey = msg.sender === loggedInUser ? msg.receiver : msg.sender;
        saveMessage(chatKey, {
            ...msg,
            isOwn: msg.sender === loggedInUser
        });

        console.log("📩 Message received from:", msg.sender);
    } catch (e) {
        console.error("❌ Failed to parse message:", e);
    }
}

// ✅ Send message on form submit
document.querySelector("#messageForm").addEventListener("submit", e => {
    e.preventDefault();
    const receiver = document.querySelector("#receiver").value.trim();
    const text = document.querySelector("#message").value.trim();
    const timestamp = new Date().toISOString();

    if (!receiver || !text) return;

    const message = {
        sender: loggedInUser,
        receiver,
        text,
        timestamp
    };

    console.log("📤 Sending:", message);

    stompClient.send("/app/chat", {}, JSON.stringify(message));

    appendMessage(text, true, receiver, formatTimestamp(timestamp));
    saveMessage(receiver, { ...message, isOwn: true });

    document.querySelector("#message").value = "";
});

// ✅ Append message to UI
function appendMessage(text, isOwn, user, timestamp) {
    const messageArea = document.querySelector("#messageArea");

    const li = document.createElement("li");
    li.style.display = "flex";
    li.style.justifyContent = isOwn ? "flex-end" : "flex-start";
    li.style.gap = "0.5rem";
    li.style.marginBottom = "6px";

    const avatar = document.createElement("div");
    avatar.textContent = user.charAt(0).toUpperCase();
    avatar.style.width = "30px";
    avatar.style.height = "30px";
    avatar.style.borderRadius = "50%";
    avatar.style.backgroundColor = isOwn ? "#2563eb" : "#999";
    avatar.style.color = "#fff";
    avatar.style.display = "flex";
    avatar.style.alignItems = "center";
    avatar.style.justifyContent = "center";
    avatar.style.fontWeight = "bold";

    const bubble = document.createElement("div");
    bubble.textContent = `${text} (${timestamp})`;
    bubble.style.padding = "8px 12px";
    bubble.style.borderRadius = "10px";
    bubble.style.maxWidth = "60%";
    bubble.style.backgroundColor = isOwn ? "#d0ebff" : "#f1f1f1";

    if (isOwn) {
        li.appendChild(bubble);
        li.appendChild(avatar);
    } else {
        li.appendChild(avatar);
        li.appendChild(bubble);
    }

    messageArea.appendChild(li);
    li.scrollIntoView({ behavior: "smooth", block: "end" });
}

// ✅ Format timestamp
function formatTimestamp(iso) {
    const d = new Date(iso);
    return `${d.toLocaleDateString()} ${d.toLocaleTimeString()}`;
}

// ✅ Save message history
function saveMessage(withUser, message) {
    const key = `chat_${withUser}`;
    const existing = JSON.parse(localStorage.getItem(key)) || [];
    existing.push(message);
    localStorage.setItem(key, JSON.stringify(existing));
}

// ✅ Load messages when receiver selected
function loadMessages(withUser) {
    const key = `chat_${withUser}`;
    const saved = JSON.parse(localStorage.getItem(key)) || [];
    const messageArea = document.querySelector("#messageArea");
    messageArea.innerHTML = "";

    saved.forEach(msg =>
        appendMessage(msg.text, msg.isOwn, msg.sender, formatTimestamp(msg.timestamp))
    );
}

// ✅ Watch receiver input
document.querySelector("#receiver").addEventListener("blur", function () {
    const receiver = this.value.trim();
    if (receiver) {
        loadMessages(receiver);
    }
});

// ✅ Show online/offline status
function setOnlineStatus(online) {
    const badge = document.querySelector(".connecting");
    if (badge) {
        badge.textContent = online ? "🟢 Online" : "🔴 Offline";
        badge.style.color = online ? "green" : "red";
    }
}

// ✅ Disconnect gracefully
window.addEventListener("beforeunload", () => {
    disconnect();
});

function disconnect() {
    if (stompClient !== null) {
        stompClient.disconnect(() => {
            console.log("🔌 Disconnected");
            setOnlineStatus(false);
        });
    }+++
}

// ✅ Try reconnect
function reconnect() {
    console.log("🔁 Reconnecting...");
    setTimeout(connectWebSocket, 5000);
}
