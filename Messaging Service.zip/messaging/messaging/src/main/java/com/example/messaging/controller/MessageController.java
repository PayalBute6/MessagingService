package com.example.messaging.controller;

import com.example.messaging.model.Message;
import com.example.messaging.service.MessageService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.handler.annotation.MessageMapping;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.messaging.simp.SimpMessageHeaderAccessor;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.stereotype.Controller;

import java.security.Principal;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

@Controller
public class MessageController {

    @Autowired
    private SimpMessagingTemplate messagingTemplate;

    @Autowired
    private MessageService messageService;

    @MessageMapping("/send")
    public void sendMessage(@Payload Message message, Principal principal) {
        // Set the sender from the authenticated user
        message.setSender(principal.getName());
        message.setTimestamp(LocalDateTime.now().format(DateTimeFormatter.ISO_LOCAL_DATE_TIME));

        // Check if receiver is online
        if (messageService.isUserOnline(message.getReceiver())) {
            // Send immediately to online receiver
            messagingTemplate.convertAndSendToUser(
                    message.getReceiver(),
                    "/queue/messages",
                    message
            );
            System.out.println("Message sent immediately to online user: " + message.getReceiver());
        } else {
            // Store message for offline user
            messageService.queueMessage(message.getReceiver(), message);
            System.out.println("Message queued for offline user: " + message.getReceiver());
        }
    }

    @MessageMapping("/connect")
    public void handleConnect(Principal principal) {
        String username = principal.getName();

        // Mark user as online
        messageService.setUserOnline(username);

        // Deliver all queued messages
        messageService.deliverQueuedMessages(username, (destination, message) -> {
            messagingTemplate.convertAndSendToUser(username, destination, message);
        });

        System.out.println("User connected: " + username);
    }

    @MessageMapping("/disconnect")
    public void handleDisconnect(Principal principal) {
        String username = principal.getName();
        messageService.setUserOffline(username);
        System.out.println("User disconnected: " + username);
    }
}