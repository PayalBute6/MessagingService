package com.example.messaging.service;

import com.example.messaging.model.Message;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.BiConsumer;

@Service
public class MessageService {

    // Track online users
    private final Set<String> onlineUsers = ConcurrentHashMap.newKeySet();

    // Queue messages for offline users
    private final Map<String, Queue<Message>> messageQueues = new ConcurrentHashMap<>();

    public boolean isUserOnline(String username) {
        return onlineUsers.contains(username);
    }

    public void setUserOnline(String username) {
        onlineUsers.add(username);
        System.out.println("User " + username + " is now online. Total online: " + onlineUsers.size());
    }

    public void setUserOffline(String username) {
        onlineUsers.remove(username);
        System.out.println("User " + username + " is now offline. Total online: " + onlineUsers.size());
    }

    public void queueMessage(String receiver, Message message) {
        messageQueues.computeIfAbsent(receiver, k -> new LinkedList<>()).offer(message);
        System.out.println("Message queued for " + receiver + ". Queue size: " +
                messageQueues.get(receiver).size());
    }

    public void deliverQueuedMessages(String username, BiConsumer<String, Message> messageDeliverer) {
        Queue<Message> userQueue = messageQueues.get(username);
        if (userQueue != null && !userQueue.isEmpty()) {
            int messageCount = userQueue.size();
            System.out.println("Delivering " + messageCount + " queued messages to " + username);

            while (!userQueue.isEmpty()) {
                Message message = userQueue.poll();
                messageDeliverer.accept("/queue/messages", message);
            }

            // Clean up empty queue
            if (userQueue.isEmpty()) {
                messageQueues.remove(username);
            }
        }
    }

    public Set<String> getOnlineUsers() {
        return new HashSet<>(onlineUsers);
    }

    public int getQueuedMessageCount(String username) {
        Queue<Message> queue = messageQueues.get(username);
        return queue != null ? queue.size() : 0;
    }
}