package com.example.messaging.service;

import com.example.messaging.model.User;
import com.example.messaging.storage.UserStorage;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UserService {

    @Autowired
    private UserStorage userStorage;

    public boolean registerUser(String username, String password) {
        if (userStorage.exists(username)) {
            return false;
        }
        userStorage.addUser(new User(username, password, false, false));
        return true;
    }

    public boolean verifyOtp(String username, String otp) {
        if (!userStorage.exists(username)) return false;
        if (!"123456".equals(otp)) return false;

        userStorage.verifyUser(username);
        return true;
    }

    public boolean validateCredentials(String username, String password) {
        User user = userStorage.getUser(username);
        return user != null && user.isVerified() && user.getPassword().equals(password);
    }

    public User getUser(String username) {
        return userStorage.getUser(username);
    }
}
